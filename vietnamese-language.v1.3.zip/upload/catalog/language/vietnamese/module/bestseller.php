<?php
// Heading 
$_['heading_title'] = 'Sản phẩm bán chạy';

// Text
$_['text_reviews']  = 'Dựa trên %s đánh giá.'; 
?>