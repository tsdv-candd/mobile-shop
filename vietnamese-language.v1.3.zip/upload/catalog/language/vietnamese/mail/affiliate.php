﻿<?php
// Text
$_['text_subject']  = '%s - Chương Trình Đại lý';
$_['text_welcome']  = 'Cám ơn bạn đã tham gia chương trình %s Đại lý!';
$_['text_approval'] = 'Tài khoản bạn phải được chấp nhận trước khi bạn có thể đăng nhập. Khi được chấp nhận bạn có thể đăng nhập bằng email và mật khẩu bằng đường dẫn sau:';
$_['text_services'] = 'Khi đăng nhập bạn có thể tạo mã theo dõi, theo dõi hoa hồng và sửa thông tin tài khoản của bạn.';
$_['text_thanks']   = 'Cám ơn,';
?>