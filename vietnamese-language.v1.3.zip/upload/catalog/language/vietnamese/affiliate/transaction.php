<?php
// Heading 
$_['heading_title']      = 'Giao dịch của bạn';

// Column
$_['column_date_added']  = 'Ngày tạo';
$_['column_description'] = 'Miêu tả';
$_['column_amount']      = 'Số tiền (%s)';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_transaction']   = 'Giao dịch của bạn';
$_['text_balance']       = 'Số dư hiện tại:';
$_['text_empty']         = 'Bạn không có giao dịch nào!';
?>