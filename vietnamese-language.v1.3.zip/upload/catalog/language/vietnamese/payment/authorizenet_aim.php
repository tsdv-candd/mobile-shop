<?php
// Text
$_['text_title']           = 'Thẻ Tín Dụng / Thẻ Ghi Nợ (Authorize.Net)';
$_['text_credit_card']     = 'Chi Tiết Thẻ';
$_['text_wait']            = 'Vui lòng đợi!';

// Entry
$_['entry_cc_owner']       = 'Chủ Thẻ:';
$_['entry_cc_number']      = 'Số Thẻ:';
$_['entry_cc_expire_date'] = 'Ngày Hết Hạn:';
$_['entry_cc_cvv2']        = 'Mã Bảo Mật (CVV2):';
?>