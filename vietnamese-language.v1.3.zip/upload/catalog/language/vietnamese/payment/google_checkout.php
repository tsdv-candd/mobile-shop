<?php
// Entry
$_['entry_postcode'] = 'Mã Bưu Điện:';
$_['entry_country']  = 'Quốc Gia:';
$_['entry_zone']     = 'Vùng / Tiểu Bang:';
?>