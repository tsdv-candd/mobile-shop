<?php
// Heading 
$_['heading_title'] = 'Sử dụng phiếu quà tặng';

// Text
$_['text_voucher']  = 'Phiếu Voucher(%s):';
$_['text_success']  = 'Thành công: Phiếu quà tặng giảm giá của bạn đã được áp dụng!';

// Entry
$_['entry_voucher'] = 'Nhập mã phiếu quà tặng của bạn tại đây:';

// Error
$_['error_voucher'] = 'Lỗi: Phiếu quà tặng không tồn tại hoặc số dư đã được sử dụng!';
?>