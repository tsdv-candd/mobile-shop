<?php
// Heading 
$_['heading_title'] = 'Áp dụng mã giảm giá';

// Text
$_['text_coupon']   = 'Mã giảm giá(%s):';
$_['text_success']  = 'Thành công: Mã giảm giả của bạn đã được áp dụng!';

// Entry
$_['entry_coupon']  = 'Nhập mã giảm giá ở đây:';

// Error
$_['error_coupon']  = 'Lỗi: Mã giảm giá không tồn tại, quá hạn hay đã được sử dụng!';
?>