<?php
// Text
$_['text_footer'] = '<a href="http://www.vinalearn.com">vinalearn.com</a> hân hạnh được cung cấp phiên bản tiếng việt cho các bạn.<br />Tác giả: Nguyễn Đức Trung - Phone: 01689.945.321';
?>