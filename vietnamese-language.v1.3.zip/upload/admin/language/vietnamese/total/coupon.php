<?php
// Heading
$_['heading_title']    = 'Khuyến mại';

// Text
$_['text_total']       = 'Tổng số đơn hàng';
$_['text_success']     = 'Thành công: Bạn đã thay đổi tổng khuyến mại!';

// Entry
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: bạn không có quyền sửa đổi tổng số phiếu!';
?>