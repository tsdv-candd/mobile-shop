<?php
// Heading
$_['heading_title']    = 'Vận chuyển';

// Text
$_['text_total']       = 'Tổng số đơn hàng';
$_['text_success']     = 'Thành công: bạn đã sửa Tổng Vận chuyển!';

// Entry
$_['entry_estimator']  = 'Tổng  Vận chuyển:';
$_['entry_status']     = 'Tình Trạng:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi Tổng vận chuyển!';
?>