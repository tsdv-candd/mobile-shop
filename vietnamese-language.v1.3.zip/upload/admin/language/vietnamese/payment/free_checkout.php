<?php
// Heading
$_['heading_title']      = 'Miễn phí thanh toán';

// Text
$_['text_payment']       = 'Thanh Toán';
$_['text_success']       = 'Thành Công: Bạn đã thay đổi phương thức Miễn phí thanh toán!';

// Entry
$_['entry_order_status'] = 'Trạng thái đơn hàng:';
$_['entry_status']       = 'Trạng thái:';
$_['entry_sort_order']   = 'Sắp xếp đơn hàng:';

// Error
$_['error_permission']   = 'Cảnh báo:Bạn không có quyền sửa đổi thanh toán Miễn phí thanh toán!';
?>