<?php
// Heading
$_['heading_title']    = 'Sơ đồ trang web Google';

// Text 
$_['text_feed']        = 'Nguồn cung cấp Sản phẩm';
$_['text_success']     = 'Thành công: Bạn đã sửa đổi nguồn cung cấp Sơ đồ trang web Google!';

// Entry
$_['entry_status']     = 'Tình trạng:';
$_['entry_data_feed']  = 'Nguồn cung cấp Url:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi nguồn cung cấp Sơ đồ trang web Google!';
?>