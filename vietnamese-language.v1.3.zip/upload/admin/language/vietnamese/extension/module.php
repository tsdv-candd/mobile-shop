<?php
// Heading
$_['heading_title']    = 'Mô-đun';

// Text
$_['text_install']     = 'Cài đặt';
$_['text_uninstall']   = 'Gỡ bỏ';

// Column
$_['column_name']      = 'Tên Mô-đun';
$_['column_action']    = 'Thao tác';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi các mô-đuns!';
?>