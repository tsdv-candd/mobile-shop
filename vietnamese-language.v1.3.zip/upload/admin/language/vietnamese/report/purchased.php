<?php
// Heading
$_['heading_title']   = 'Báo cáo mua hàng';

// Column
$_['column_name']     = 'Tên sản phẩm';
$_['column_model']    = 'Model';
$_['column_quantity'] = 'Số lượng';
$_['column_total']    = 'Tổng';
?>
