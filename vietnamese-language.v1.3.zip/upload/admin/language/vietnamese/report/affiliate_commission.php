<?php
// Heading
$_['heading_title']     = 'Báo cáo hoa hồng cho đại lý';

// Column
$_['column_affiliate']  = 'Tên đại lý';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Trạng thái';
$_['column_commission'] = 'Hoa hồng';
$_['column_orders']     = 'Số đơn hàng';
$_['column_total']      = 'Tổng cộng';
$_['column_action']     = 'Thao tác';

// Entry
$_['entry_date_start']  = 'Ngày bắt đầu:';
$_['entry_date_end']    = 'Ngày kết thúc:';
?>