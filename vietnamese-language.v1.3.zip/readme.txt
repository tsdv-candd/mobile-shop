/** 	This is free license from http://vinalearn.com
	Author: Nguyen Duc Trung - commitflame@gmail.com - (+84).1689.945.321
	If you have any question. Please contact with me follow my email.
**/

Step 1: Uploading admin and catalog folder on your server

Step 2: Go Administrator > System > Localisation > Languages > Insert:

a. Language name: vietnamese
b. Code: 	vi
c. Locale: 	vi_VN.UTF-8,vi_VN,vi-vn,vietnamese
d. Image: 	vn.png
e. Directory: 	vietnamese
f. Filename: 	vietnamese
> Save

Step 3: Go Administrator > System > Settings > Your Store > Edit > Local: 
a. Language: Vietnamese (Apply for your store)
b. Administration language: Vietnamese (Apply for your adminitration store)

Version:
1.0: base

1.1:(28/07/2012)
fig bug template setting

1.2:(22/09/2012)
fig bug module products

1.2:(19/11/2012)
fix for OS version 1.5.4